﻿configuration FeatureInstallation
{
   param
    (
        [Parameter(Mandatory)]
        [string]$features
    )
    Node ("localhost"){
    
        WindowsFeature "Windowsfeature"
        {
            Ensure = "Present"
            Name = $features
            
        }


    }

}