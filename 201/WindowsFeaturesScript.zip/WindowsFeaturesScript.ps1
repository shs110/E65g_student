﻿configuration FeatureInstallation
{
   param
    (
        [Parameter(Mandatory)]
        [string[]]$features
    )
    foreach($feature in $features)
    {
    Node ("localhost"){
    
        WindowsFeature "Windowsfeature"
        {
            Ensure = "Present"
            Name = $feature
            
        }
        Log "netserverWindowsFeatures-$feature"
            {
                Message = "netserverWindowsFeatures Windows $feature updated"
                #DependsOn = "[WindowsFeature]"
            }


    }
    }
}